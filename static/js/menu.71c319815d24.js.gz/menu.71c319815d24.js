

  document.addEventListener('DOMContentLoaded', () => {
    $('#idVentas')
      .dropdown()
      ;
    $('#idGastos')
      .dropdown()
      ;
  });
