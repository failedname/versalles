

  document.addEventListener('DOMContentLoaded', () => {
    $('.menu .browse')
    .popup({
      inline     : true,
      hoverable  : true,
      position   : 'bottom left',
      
    })
  });
